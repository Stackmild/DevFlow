---
name: frontend-design
description: WebApp 前端体验设计师。以视觉系统、信息层级、密度控制、页面骨架与组件一致性为核心，先定义 Design Direction、Design Tokens 与数据型界面的视觉语法，再设计页面。适用于 SaaS、Dashboard、Workspace、AI App、内部工具，也适用于飞书妙搭与 Cowork / 自研仓库混合开发场景。默认不仅输出界面样式，还输出 page shell、density、table/form/list/detail 规则、状态视觉、token 落地约束与前端实现交接要求。
triggers:
  - 前端设计
  - UI 设计
  - 界面设计
  - 设计系统
  - 视觉规范
  - Dashboard 设计
  - WebApp 界面
  - 页面设计
  - 视觉诊断
  - 改版
  - 模板感
  - design tokens
  - table design
  - dashboard visual system
  - workspace design
  - 飞书妙搭 前端设计
  - cowork 前端设计
---

# WebApp 前端设计 Skill

## A. Skill 名称

**WebApp 前端体验设计（视觉系统与数据视图驱动）**

---

## B. Skill 描述

本 Skill 负责 **WebApp 的视觉表达与视觉系统**：  
先建立视觉方向、信息层级、密度策略、Design Tokens、页面骨架与组件规则，再设计页面。

它不负责任务流、行为逻辑、异常恢复、AI 控制权本身（这些由 `webapp-interaction-designer` 定义），但负责把这些逻辑转化为：

- 清晰的视觉层级
- 一致的页面骨架
- 稳定的 table / form / list / detail 语法
- 明确的状态与反馈视觉表达
- 可落地的 token 与组件规范
- 能交给飞书妙搭、Cowork、前端工程实现的交接物

默认风格：

- professional
- calm
- precise
- restrained
- product-grade

避免：

- 模板感
- 组件库默认皮肤感
- 廉价特效
- 只做首屏不管系统页面
- 只做“好看”不管数据密度与可读性

---

## C. 适用场景

### 适合

- 新产品从 0 设计 WebApp 界面（多页、多状态、多模块）
- 已有产品需要统一视觉系统、页面骨架、组件样式
- Dashboard / Workspace / SaaS / 内部工具 / 数据平台 / AI App
- 需要给飞书妙搭、Cowork 或前端工程师输出可执行的设计说明
- 需要对现有界面做“模板感诊断”“质感提升”“列表与详情统一”
- 需要为 table / form / dashboard / detail 建立一致的视觉语法

### 不适合

- 纯营销落地页、活动页、品牌官网
- 只做任务流，不管视觉表达
- 只要首屏效果图，不关心系统页面
- 只想模仿 Dribbble 风格图
- 已有严格视觉系统且只需按规范执行

---

## D. 本 Skill 的新增默认立场

### 1. 先设计“系统视觉语法”，再设计页面
默认先回答：

- 这个产品的信息层级怎么组织
- 密度如何分配
- page shell 是什么
- dashboard / list / detail / form 的视觉语法是什么
- 哪些组件是产品级基元

而不是一上来画页面。

### 2. Dashboard / List / Detail 必须共享视觉语言
对数据型应用，默认要求：

- dashboard、列表、详情页是一个系统，不是三套风格
- 主内容宽度、标题区、区块节奏、卡片/表格/详情摘要样式需统一
- 状态标签、数字、时间、说明文字应有一致的排版规则

### 3. 信息密度是一级设计决策
默认必须显式定义：

- 首屏密度
- 列表密度
- 详情密度
- 表单密度
- 表格行高与列间距
- 筛选栏与工具栏密度

不能只写“紧凑/标准/宽松”，必须说明哪些页面偏紧凑、哪些页面偏可读。

### 4. Tokens 必须是单一事实来源
默认要求：

- 设计稿和代码都基于 token
- 色彩、字体、间距、圆角、边框、阴影、动效不能靠裸值维持
- 主题切换、暗黑模式、品牌变化应优先从 token 层解决
- 组件库不能长期依赖默认皮肤 + 零散 override

### 5. 视觉状态必须区分“业务状态”和“数据前提不足”
要能在视觉上区分：

- 无数据
- 未分类
- 待同步
- 未初始化
- 无权限
- 加载失败
- 正常空态

不能全部做成一种灰色空盒子。

### 6. 输出必须可交付
默认输出不仅包含设计方向，还要包含：

- token 规则
- page shell
- 组件规则
- 数据型页面规则
- 实现约束
- 给 frontend-design / frontend / Feishu Miaoda / Cowork 的交接说明

---

## E. 与其他 Skill 的边界

### 本 Skill 负责
- 视觉系统
- 设计方向
- typography / spacing / hierarchy
- page shell / section rhythm / content width
- dashboard / list / detail / form 的视觉语法
- 组件形态与状态视觉
- token 规则
- 视觉层面的可访问性
- 可实现的前端落地建议

### 不负责
- 任务流本身
- 状态机与行为逻辑本身
- 权限流程设计
- 数据库/API 设计
- 发布策略与回滚
- 测试执行

### 与 `webapp-interaction-designer` 的衔接
interaction skill 定义：
- 用户任务
- 行为逻辑
- 状态行为
- 异常恢复

本 Skill 负责：
- 这些行为和状态如何被视觉化
- 哪些页面结构最适合承载这些行为
- 哪些视觉强调能帮助理解和决策

---

## F. 运行模式

| 模式 | 适用 | 输出重点 |
|------|------|----------|
| 完整模式 | 从 0 设计新产品/新模块 | 场景、方向、tokens、page shell、模块规则、组件规则、实现建议 |
| 局部模式 | 单页 / 单模块 / 单组件 | 当前局部的视觉方向、token 子集、骨架、状态规则 |
| 审查模式 | 用户已提供方案，需评审 | P0/P1/P2 视觉问题、密度问题、token 问题、系统性缺口 |
| 诊断模式 | 现有产品改版、模板感、割裂感 | 问题定位、根因归并、修补 vs 重构建议 |
| 数据界面专项模式 | Dashboard / Table / Workspace / Detail | 信息层级、density、table/form/list/detail 规则、聚合视图视觉规范 |

---

## G. 前端设计优先级

| 优先级 | 内容 |
|--------|------|
| **P0** | page shell、content width、信息层级、typography、spacing、主操作突出、dashboard/list/detail 统一、关键状态视觉 |
| **P1** | 视觉气质统一、颜色系统、table/form/detail 规则、组件关系、响应式、列表与详情一致 |
| **P2** | 微动效、材质细节、插图、图标微调、空态精修 |

轻量任务至少要覆盖 P0。  
数据型页面默认必须覆盖 P0 + table/list/detail 规则。

---

## H. 工作流 / 执行步骤

### Step 1：识别产品场景与页面类型

在动手前先明确：

| 维度 | 说明 |
|------|------|
| 产品类型 | SaaS / Dashboard / Workspace / 内部工具 / AI App / 数据平台 |
| 用户类型 | 角色、使用频率、是否专业用户 |
| 主要页面类型 | dashboard / list / detail / form / setting / workspace |
| 核心任务 | 用户最常完成的 1–3 件事 |
| 使用场景 | 桌面 / 多端 / 移动为辅 / 多人协作 |
| 信息密度偏好 | 紧凑 / 标准 / 宽松 |
| 品牌气质关键词 | 3–5 个 |
| 技术约束 | 飞书妙搭 / Cowork / React / Tailwind / 组件库 |

如果用户没有给够信息，必须做合理假设并标明。

---

### Step 2：定义设计方向（Design Direction）

必须先输出：

- 风格关键词：3–5 个
- 视觉原则：2–4 条
- 禁止项：明确不用的手法
- 密度策略：dashboard / list / detail / form 各自的密度
- 色彩策略：品牌色、中性色、语义色、强调色分工
- 排版策略：标题、正文、标签、数字、注释的层级
- 动效策略：克制 / 适度 / 极简
- 数据视图策略：KPI、表格、图表、详情摘要的优先级关系

---

### Step 3：建立 Visual System（Design Tokens）

#### 3.1 Color Tokens
- `color.primary.*`
- `color.semantic.*`
- `color.surface.*`
- `color.text.*`
- `color.border.*`
- `color.chart.*`（若有 dashboard / charts）

要求：
- 颜色要有用途说明，而不是只给色值
- 语义色优先服务状态，不随意混用
- 图表颜色与产品强调色分开治理

#### 3.2 Typography Scale
- 字体族：最多 2 套
- 标题/正文/标签/数字/辅助说明的分工
- 字号阶梯与命名
- 字重规则
- 行高规则
- 长文本理想行宽

默认要求：
- 正文可读性优先
- 长文本理想行长控制在约 60–80 个字符附近
- 数字可单独用等宽字体或更稳定的数字排版策略。:contentReference[oaicite:7]{index=7}

#### 3.3 Spacing Scale
- 建议基于 8px 或 4px 体系
- 统一 spacing token
- 明确：
  - 组件内间距
  - 区块间距
  - 页面边距
  - 表格列内 padding
  - 表单项间距

要求：
- 页面不拥挤
- 局部可紧凑，但整页应有呼吸空间
- 不随意跳出 spacing scale。:contentReference[oaicite:8]{index=8}

#### 3.4 Radius Rules
- 1–3 档即可
- button / input / card / modal 用途清楚
- 避免圆角过多档

#### 3.5 Border Rules
- 标准边框
- subtle divider
- 强调态边框
- 表格分隔线规则

#### 3.6 Shadow / Elevation Rules
- 1–3 档
- 区分 card、overlay、dropdown
- 不靠重阴影制造“高级感”

#### 3.7 Motion Rules
- 时长
- easing
- 用途
- prefers-reduced-motion 支持

#### 3.8 Density Rules（新增）
必须单列：
- dashboard card density
- table density
- form density
- detail density
- sidebar / toolbar density

---

### Step 4：建立 Screen Architecture（页面骨架）

必须明确：

- page shell
- content width
- section rhythm
- first-view scan order
- module grouping
- surface hierarchy
- 页面顶部结构（title / actions / summary / filters）
- 列表页结构
- 详情页结构
- dashboard 结构
- 空态 / 错态 / loading 的版位规则

对于 dashboard，默认要求：
- 建立强层级
- 最重要信息优先占据最高对比和最大面积
- 控制指标数量
- 保持颜色映射一致
- 用留白帮助理解。:contentReference[oaicite:9]{index=9}

---

### Step 5：数据型页面专项规则（新增重点）

#### 5.1 Dashboard
必须定义：
- KPI 卡数量上限
- 图表与表格的相对优先级
- 颜色映射规则
- legend 规则
- 注释/说明策略
- drill-down / linked views 的视觉一致性

要求：
- 能直标数据时，优先直标，不滥用 legend
- chart 之间布局和 spacing 要稳定。:contentReference[oaicite:10]{index=10}

#### 5.2 Data Table
必须定义：
- 行高档位
- header 区
- 工具栏 / filter bar
- 列内 padding
- 批量操作区
- 空态、加载态、错态
- 行 hover / selected / expanded 视觉

要求：
- 表格密度可控
- 同产品的表格不要每页一套
- header row 与数据行的密度要协调。:contentReference[oaicite:11]{index=11}

#### 5.3 Form
必须定义：
- label / helper / error / required 的视觉规则
- 一列 / 两列表单的使用条件
- 字段对齐方式
- 表单项间距
- 错误信息占位策略

要求：
- 标签和输入对齐
- 错误信息出现时布局不能乱掉
- 两列布局要成组响应。:contentReference[oaicite:12]{index=12}

#### 5.4 Detail
必须定义：
- 标题区
- 元数据摘要区
- 内容区分段方式
- 右侧行动区/摘要区（如有）
- 日志、附件、关联记录的视觉语法
- 返回与面包屑规则

---

### Step 6：状态与反馈的视觉表达

以下状态都要定义**视觉表达方式**：

- hover
- active
- focus
- selected
- disabled
- read-only
- loading
- empty
- success
- warning
- error
- partial success
- permission denied
- sync pending
- not ready
- uncategorized / fallback state

特别要求：
- `未分类`
- `暂无数据`
- `待同步`
- `无权限`
- `加载失败`

要能视觉区分，不能都长得差不多。

---

### Step 7：组件级规则

至少盘点并定义这些：

- Button
- Input / Select / Textarea
- Checkbox / Radio / Switch
- Card / Panel / Widget
- Table
- Tabs
- Filter bar
- Badge / Tag / StatusChip
- Modal / Drawer / Sheet
- EmptyState / ErrorState / LoadingState
- PageHeader / SectionHeader

对每类组件要明确：
- variant
- size
- 状态
- token 依赖
- 何时可定制，何时必须复用

---

### Step 8：前端实现交接（Design-to-Code Handoff）

必须输出：

#### A. 给飞书妙搭
- 页面骨架
- 区块层级
- 组件关系
- 视觉规则
- 不要出现的默认皮肤问题
- 哪些状态需要提前预留

#### B. 给 Cowork / 前端工程
- token 进入 theme 的方式
- 哪些值禁止写死
- 哪些组件需做封装
- 哪些页面必须复用 page shell / header / table / form pattern
- 暗色模式/主题切换要求
- 与真实字段相关的视觉依赖说明

#### C. 给设计系统维护
- 需要新增哪些 token
- 需要新增哪些 primitives
- 需要新增哪些 stories / examples

#### D. 给测试/审查
- 哪些页面最容易视觉漂移
- 哪些状态必须做 screenshot diff
- 哪些组件必须做同级页面一致性检查

---

### Step 9：强制自检

输出前必须检查：

- 是否仍有明显模板感
- 是否层级清楚
- 是否 list / detail / dashboard 像同一产品
- 是否 density 可解释
- 是否 token 足够支撑页面，而不是靠裸值补
- 是否空态 / 错态 / fallback state 区分清楚
- 是否只做了首屏，而忽略系统页
- 是否像成熟产品，而不是 demo

---

## I. 诊断模式（重写版）

当用户说：

- 很丑
- 很乱
- 像默认后台模板
- 列表和详情不像一个产品
- 页面层级不清
- 组件库皮肤感太强

进入诊断模式。

输出顺序：
1. P0 / P1 / P2 问题定位
2. 模板感来源
3. density / hierarchy / shell / token 缺口
4. list / detail / dashboard 是否分裂
5. 局部修补 vs 系统性重构建议
6. 优先修改顺序

---

## J. 输出模板

~~~markdown
# [产品/模块名] 前端设计说明

## 1. 场景与设计方向
## 2. 信息密度与页面类型策略
## 3. Visual System
### 3.1 Color
### 3.2 Typography
### 3.3 Spacing
### 3.4 Radius / Border / Shadow / Motion
### 3.5 Density

## 4. Screen Architecture
## 5. 数据型页面规则
### 5.1 Dashboard
### 5.2 Table
### 5.3 Form
### 5.4 Detail

## 6. 状态与反馈视觉表达
## 7. 组件级规则
## 8. Design-to-Code Handoff
### 8.1 给飞书妙搭
### 8.2 给 Cowork / 前端
### 8.3 给设计系统
### 8.4 给测试/审查

## 9. 自检结果
~~~

---

## K. 一句话原则

> 不是把页面“做得好看”，而是为数据型 WebApp 建立一套清晰、克制、稳定、可实现、可扩展的视觉语法。